function D = updateDs(varargin)
% Unified updateDs function
% Handles both U (matrix) and V (vectors)

if nargin == 1
    % Case for U: L2,1 norm of a matrix
    U = varargin{1};
    vlen = size(U, 1); % Number of rows in U
    d = zeros(vlen, 1);
    for i = 1:vlen
        d(i) = sqrt(sum(U(i, :).^2) + eps); % L2 norm of row i
    end
    D = 0.5 ./ d;

else
    % Case for V: Multiple vectors (v1, v2, v3, ...)
    vlen = length(varargin{1});
    d = zeros(vlen, 1);
    for i = 1:vlen
        sum_of_squares = 0;
        for j = 1:nargin
            sum_of_squares = sum_of_squares + varargin{j}(i)^2;
        end
        d(i) = sqrt(sum_of_squares + eps); % L2 norm across vectors
    end
    D = 0.5 ./ d;
end
end
