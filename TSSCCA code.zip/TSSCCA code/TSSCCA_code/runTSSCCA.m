clc; clear;

% Load data
addpath('./SCCA_func/');
addpath('./flsa/');
addpath('./q1/');
%addpath('.\tensor_toolbox-master\');
load Simulated_TSSCCA_data.mat;
n_modality = 4;
% Load precomputed similarity matrix

% Set Laplacian matrix
S = (S + S') / 2; % Ensure symmetry
S = S - diag(diag(S)); % Zero diagonal
D = diag(sum(S, 2));
L = D - S;

% Set parameters for TSSCCA
topts = struct();
topts.L= L;
topts.lambda.u2 = 0.001; % L1-norm, individual sparsity
topts.lambda.u3 = 0.1; % L21-norm, individual across tasks
topts.lambda.u1 = 0.001;

topts.lambda.v1 = 0.001;
topts.lambda.v2 = 0.01;
topts.lambda.v3 = 0.0001;
topts.gamma_u = 0.01;
% Cross-Validation
Kfold = 5;
[n_sbj, ~] = size(X);
indices = crossvalind('Kfold',n_sbj,Kfold);
% disp('=====================================');
disp('Begin cross validition ...');
disp('===========================');
for k = 1:Kfold
    fprintf('current fold: %d\n',k);
    
    test_idx = indices==k;
    train_idx = ~test_idx;
    
    % set training and testing sets
    % training set
    itrain_set.X = getNormalization(X(train_idx,:));
    itrain_set.Y1 = getNormalization(Y1(train_idx,:));
    itrain_set.Y2 = getNormalization(Y2(train_idx,:));
    itrain_set.Y3 = getNormalization(Y3(train_idx,:));
    itrain_set.Y4 = getNormalization(Y4(train_idx,:));
    
    % testing set
    itest_set.X = getNormalization(X(test_idx,:));
    itest_set.Y1 = getNormalization(Y1(test_idx,:));
    itest_set.Y2 = getNormalization(Y2(test_idx,:));
    itest_set.Y3 = getNormalization(Y3(test_idx,:));
    itest_set.Y4 = getNormalization(Y4(test_idx,:));
tic;
[u_tsscca, v_tsscca] = TSSCCA(itrain_set, topts);
timecost.tsscca(k) = toc;
% CC
% X-Y1
corr_train.tsscca1(k) = corr(itrain_set.X*u_tsscca(:,1), itrain_set.Y1*v_tsscca(:,1));
corr_test.tsscca1(k) = corr(itest_set.X*u_tsscca(:,1), itest_set.Y1*v_tsscca(:,1));
% X-Y2
corr_train.tsscca2(k) = corr(itrain_set.X*u_tsscca(:,2), itrain_set.Y2*v_tsscca(:,2));
corr_test.tsscca2(k) = corr(itest_set.X*u_tsscca(:,2), itest_set.Y2*v_tsscca(:,2));
% X-Y3
corr_train.tsscca3(k) = corr(itrain_set.X*u_tsscca(:,3), itrain_set.Y3*v_tsscca(:,3));
corr_test.tsscca3(k) = corr(itest_set.X*u_tsscca(:,3), itest_set.Y3*v_tsscca(:,3));
% X-Y4
corr_train.tsscca4(k) = corr(itrain_set.X*u_tsscca(:,4), itrain_set.Y4*v_tsscca(:,4));
corr_test.tsscca4(k) = corr(itest_set.X*u_tsscca(:,4), itest_set.Y4*v_tsscca(:,4));
% u, v
u1_tsscca(:,k) = u_tsscca(:,1);
v1_tsscca(:,k) = v_tsscca(:,1);
u2_tsscca(:,k) = u_tsscca(:,2);
v2_tsscca(:,k) = v_tsscca(:,2);
u3_tsscca(:,k) = u_tsscca(:,3);
v3_tsscca(:,k) = v_tsscca(:,3);
u4_tsscca(:,k) = u_tsscca(:,4);
v4_tsscca(:,k) = v_tsscca(:,4);
end
disp('===========================');
id_tsscca = 1;
% mean top best CC
cc_train.tsscca = [corr_train.tsscca1', corr_train.tsscca2', corr_train.tsscca3', corr_train.tsscca4'];
cc_test.tsscca = [corr_test.tsscca1', corr_test.tsscca2', corr_test.tsscca3', corr_test.tsscca4'];
istats.meancctr(id_tsscca,:) = mean(abs(cc_train.tsscca));
istats.meanccte(id_tsscca,:) = mean(abs(cc_test.tsscca));
% mean U and V
TSU = [mean(u1_tsscca,2),mean(u2_tsscca,2),mean(u3_tsscca,2),mean(u4_tsscca,2)];
TSV = [mean(v1_tsscca,2), mean(v2_tsscca,2), mean(v3_tsscca,2), mean(v4_tsscca,2)];
